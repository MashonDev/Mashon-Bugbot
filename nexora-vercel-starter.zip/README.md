# Nexora — Next.js + Vercel starter

Responsive purple sci-fi landing page, sign-in/sign-up screens, dashboard and WhatsApp pairing UI.

## Run locally
1. Install Node.js 20+.
2. Extract this project and open the folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Visit http://localhost:3000

## Optional Supabase auth
Create a Supabase project. In Authentication settings, enable Email/password and optionally Google OAuth.
Copy `.env.example` to `.env.local`, then fill:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

Without those values, the login/register pages show a demo-mode message and let you enter the UI (not secure authentication). Set Supabase values before real use.

## Deploy to Vercel
Push this folder to GitHub, import the repository at Vercel, and add the two environment variables in Project Settings → Environment Variables. Deploy.

## WhatsApp pairing
The pairing page is a UI shell only. It does not connect WhatsApp, create pairing codes, store credentials, or run a bot.
For real pairing, run your WhatsApp library on a persistent backend (VPS/container), expose authenticated API endpoints, and connect the UI to them. Do not put bot credentials or session keys in frontend code or Vercel environment variables exposed with `NEXT_PUBLIC_`.

## Production checklist
- Enable Supabase auth and set redirect URLs for localhost and your deployed domain.
- Add server-side authorization checks for protected APIs.
- Implement rate limiting and abuse protection.
- Keep WhatsApp connection/session handling on a secure backend.
- Add database tables and policies before allowing users to manage sessions.
